﻿namespace WebApplication2.Models
{
    public class Employee
    {
        public string Title { get; set; }
        public string US_Gross { get; set; }
        public string Worldwide_Gross { get; set; }
        public string US_DVD_Sales { get; set; }
        public string Production_Budget { get; set; }
        public string Release_Date { get; set; }
        public string MPAA_Rating { get; set; }
        public string Running_Time_min { get; set; }
        public string Distributor { get; set; }
        public string Source { get; set; }
        public string Major_Genre { get; set; }
        public string Creative_Type { get; set; }
        public string Director { get; set; }
        public string Rotten_Tomatoes_Rating { get; set; }
        public string IMDB_Rating { get; set; }
        public string IMDB_Votes { get; set; }
    }


}
