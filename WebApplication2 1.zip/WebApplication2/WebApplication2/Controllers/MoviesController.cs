﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : Controller
    {

        [HttpGet("GetUserDetails")]
        public IActionResult GetUserDetails()
        {
            string path = @"D:\db.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }

            JObject a = JObject.Parse(json);
            if (a != null)
            {
                JArray c = (JArray)a["movie"];
                IList<Employee> person = c.ToObject<IList<Employee>>();
                return Ok(person);
            }
            return Ok();
        }

        [HttpPost("Add")]
        public IActionResult Add(Employee employee)
        {
            string path = @"D:\db.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }
            JObject jsonObj = JObject.Parse(json);
            var newCompanyMember = "{ 'Title': '" + employee.Title + "', 'US_Gross': '" + employee.US_Gross + "', 'Worldwide_Gross': '" + employee.Worldwide_Gross + "'" +
                ", 'US_DVD_Sales': '" + employee.US_DVD_Sales + "', 'Production_Budget': '" + employee.Production_Budget + "', 'Release_Date': '" + employee.Release_Date + "'" +
                ", 'MPAA_Rating': '" + employee.MPAA_Rating + "', 'Running_Time_min': '" + employee.Running_Time_min + "', 'Distributor': '" + employee.Distributor + "'" +
                ", 'Source': '" + employee.Source + "', 'Major_Genre': '" + employee.Major_Genre + "', 'Creative_Type': '" + employee.Creative_Type + "'" +
                ", 'Director': '" + employee.Director + "', 'Rotten_Tomatoes_Rating': '" + employee.Rotten_Tomatoes_Rating + "', 'IMDB_Rating': '" + employee.IMDB_Rating + "', 'IMDB_Votes': '" + employee.IMDB_Votes + "'    }";

            var experienceArrary = jsonObj.GetValue("movie") as JArray;
            JObject newCompany = JObject.Parse(newCompanyMember);
            experienceArrary.Add(newCompany);

            jsonObj["movie"] = experienceArrary;
            string newJsonResult = JsonConvert.SerializeObject(jsonObj,
                                   Formatting.Indented);

            using (var fs = new FileStream(path, FileMode.Truncate))
            {
                fs.Close();
            }

            using (var tw = new StreamWriter(path, true))
            {
                tw.WriteLine();
                tw.WriteLine(newJsonResult);
                tw.Close();
            }

            JArray c = (JArray)jsonObj["movie"];
            IList<Employee> person = c.ToObject<IList<Employee>>();
            return Ok(new { Success = "Created successfully" });
        }


        [HttpPost("Update")]
        public IActionResult Update(Employee employee)
        {
            string path = @"D:\db.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }
            JObject jsonObj = JObject.Parse(json);
            JArray experiencesArrary = (JArray)jsonObj["movie"];


            IList<Employee> per = experiencesArrary.ToObject<IList<Employee>>();
            int count = per.Where(c => c.Title == employee.Title).Count();


            if (count == 1)
            {
                foreach (var company in experiencesArrary.Where(obj => obj["Title"].Value<string>() == employee.Title))
                {
                    company["US_Gross"] = !string.IsNullOrEmpty(employee.US_Gross) ? employee.US_Gross : company["US_Gross"].ToString();
                    company["Worldwide_Gross"] = !string.IsNullOrEmpty(employee.Worldwide_Gross) ? employee.Worldwide_Gross : company["Worldwide_Gross"].ToString();
                    company["US_DVD_Sales"] = !string.IsNullOrEmpty(employee.US_DVD_Sales) ? employee.US_DVD_Sales : company["US_DVD_Sales"].ToString();
                    company["Production_Budget"] = !string.IsNullOrEmpty(employee.Production_Budget) ? employee.Production_Budget : company["Production_Budget"].ToString();
                    company["Release_Date"] = !string.IsNullOrEmpty(employee.Release_Date) ? employee.Release_Date : company["Release_Date"].ToString();
                    company["MPAA_Rating"] = !string.IsNullOrEmpty(employee.MPAA_Rating) ? employee.MPAA_Rating : company["MPAA_Rating"].ToString();
                    company["Running_Time_min"] = !string.IsNullOrEmpty(employee.Running_Time_min) ? employee.Running_Time_min : company["Running_Time_min"].ToString();
                    company["Distributor"] = !string.IsNullOrEmpty(employee.Distributor) ? employee.Distributor : company["Distributor"].ToString();
                    company["Source"] = !string.IsNullOrEmpty(employee.Source) ? employee.Source : company["Source"].ToString();
                    company["Major_Genre"] = !string.IsNullOrEmpty(employee.Major_Genre) ? employee.Major_Genre : company["Major_Genre"].ToString();
                    company["Creative_Type"] = !string.IsNullOrEmpty(employee.Creative_Type) ? employee.Creative_Type : company["Creative_Type"].ToString();
                    company["Director"] = !string.IsNullOrEmpty(employee.Director) ? employee.Director : company["Director"].ToString();
                    company["Rotten_Tomatoes_Rating"] = !string.IsNullOrEmpty(employee.Rotten_Tomatoes_Rating) ? employee.Rotten_Tomatoes_Rating : company["Rotten_Tomatoes_Rating"].ToString();
                    company["IMDB_Rating"] = !string.IsNullOrEmpty(employee.IMDB_Rating) ? employee.IMDB_Rating : company["IMDB_Rating"].ToString();
                    company["IMDB_Votes"] = !string.IsNullOrEmpty(employee.IMDB_Votes) ? employee.IMDB_Votes : company["IMDB_Votes"].ToString();
                }

                jsonObj["movie"] = experiencesArrary;
                string output = Newtonsoft.Json.JsonConvert.SerializeObject(jsonObj, Newtonsoft.Json.Formatting.Indented);

                using (var fs = new FileStream(path, FileMode.Truncate))
                {
                    fs.Close();
                }

                using (var tw = new StreamWriter(path, true))
                {
                    tw.WriteLine(output);
                    tw.Close();
                }
                JArray c = (JArray)jsonObj["movie"];
                IList<Employee> person = c.ToObject<IList<Employee>>();
                return Ok(new { Success = "Updated successfully" });
            }
            else if (count > 1)
            {
                return Ok(new { error = "Title is not unique" });
            }
            else
            {
                return Ok("Not found");
            }
        }


        [HttpPost("Delete")]
        public IActionResult Delete(Employee employee)
        {
            var newCompanyMember = "{ 'Title': '" + employee.Title + "'}";

            string path = @"D:\db.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }

            JObject jObject = JObject.Parse(json);
            JArray experiencesArrary = (JArray)jObject["movie"];

            if (employee.Title != null)
            {
                var companyName = string.Empty;
                var companyToDeleted = experiencesArrary.FirstOrDefault(obj => obj["Title"].Value<string>() == employee.Title);

                experiencesArrary.Remove(companyToDeleted);

                string output = Newtonsoft.Json.JsonConvert.SerializeObject(jObject, Newtonsoft.Json.Formatting.Indented);
                using (var fs = new FileStream(path, FileMode.Truncate))
                {
                    fs.Close();
                }

                using (var tw = new StreamWriter(path, true))
                {

                    tw.WriteLine(output);
                    tw.Close();
                }
                JArray c = (JArray)jObject["movie"];
                IList<Employee> person = c.ToObject<IList<Employee>>();
                return Ok(new { Success = "Deleted successfully" });
            }
            else
            {
                Console.Write("Invalid title!");
                return Ok();
            }
        }

        [HttpPost("GetMovieByTitle")]
        public IActionResult GetMovieByTitle(Employee employee)
        {
            string path = @"D:\db.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }

            JObject a = JObject.Parse(json);
            if (a != null)
            {
                JArray c = (JArray)a["movie"];
                IList<Employee> person = c.ToObject<IList<Employee>>();
                Employee employee1 = person.Where(x => x.Title == employee.Title).FirstOrDefault();
                if (employee1 != null)
                {
                    return Ok(new { data = employee1 });
                }
                else
                {
                    return Ok(new { data = "Movie not found" });
                }
            }
            return Ok();
        }


        [HttpGet("GetMoviesByGenre")]
        public IActionResult GetMoviesByGenre()
        {
            string path = @"D:\db.json";
            string json;
            int g = 0;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }
            JObject a = JObject.Parse(json);
            if (a != null)
            {
                JArray c = (JArray)a["movie"];
                IList<Employee> person = c.ToObject<IList<Employee>>();

                var data = from z in person
                           group z by z.Major_Genre
                         into kd
                           orderby kd.Key
                           select new
                           {
                               genre = kd.Key,
                               details = kd,
                               count = kd.Count()
                           };

                Hashtable h = new Hashtable();
                foreach (var item in data)
                {
                    string genre = item.genre;
                    int NumberOfMovies = item.count;
                    h.Add(string.IsNullOrEmpty(genre) ? "null" : genre, NumberOfMovies);
                }
                return Ok(h);
            }
            return Ok();
        }

        [HttpGet("GetMoviesByYear")]
        public IActionResult GetMoviesByYear()
        {
            string path = @"D:\db.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }
            JObject a = JObject.Parse(json);
            if (a != null)
            {
                JArray c = (JArray)a["movie"];
                IList<Employee> person = c.ToObject<IList<Employee>>();

                var data = from z in person
                           group z by z.Release_Date.Substring(Math.Max(0, z.Release_Date.Length - 4))
                into kd
                           orderby kd.Key
                           select new
                           {
                               genre = kd.Key,
                               details = kd,
                               count = kd.Count()
                           };

                Hashtable h = new Hashtable();
                foreach (var item in data)
                {
                    string year = item.genre;
                    int NumberOfMovies = item.count;
                    h.Add(string.IsNullOrEmpty(year) ? "null" : year, NumberOfMovies);
                }
                return Ok(h);
            }
            return Ok();
        }


    }
}
